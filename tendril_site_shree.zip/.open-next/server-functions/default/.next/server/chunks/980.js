exports.id=980,exports.ids=[980],exports.modules={6183:(a,b,c)=>{Promise.resolve().then(c.bind(c,4548)),Promise.resolve().then(c.bind(c,24207)),Promise.resolve().then(c.bind(c,52402)),Promise.resolve().then(c.bind(c,65698)),Promise.resolve().then(c.bind(c,11363)),Promise.resolve().then(c.bind(c,60833))},11363:(a,b,c)=>{"use strict";c.d(b,{default:()=>l});var d=c(21124),e=c(3991),f=c.n(e),g=c(15982),h=c(46267),i=c(71213);function j({href:a,children:b,className:c,...e}){return a?!function(a=""){return/^https?:\/\//i.test(a)}(a)?(0,d.jsx)(f(),{href:a,className:c,...e,children:b}):(0,d.jsx)("a",{href:a,target:"_blank",rel:"noreferrer",className:c,...e,children:b}):null}let k=[{title:"Services",links:[{label:"Build",href:"/services"},{label:"Automate",href:"/services"},{label:"Scale",href:"/services"}]},{title:"Company",links:[{label:"About Us",href:"/about"},{label:"Solutions",href:"/solutions"},{label:"Contact",href:"/contact"}]}];function l({settings:a}){let b=(a?.footerColumns||[]).map(a=>({...a,links:(a.links||[]).filter(a=>"resources"!==String(a?.label||"").toLowerCase()&&a?.href)})).filter(a=>a?.title&&Array.isArray(a.links)&&a.links.length>0),c=b.length>0?b:k,e=(a?.socialLinks||[]).filter(a=>a?.url&&a?.platform),l=a?.footerCta?.href?a.footerCta:null,m=a?.contactEmail||a?.email||"contact@tendrils.io",n=a?.contactPhone||a?.phone||"+1 214 302 9093",o=a?.footerDescription||"We design, build, automate, and scale digital commerce systems for ambitious brands.",p=a?.footerLogo?.assetUrl||a?.footerLogo?.asset?.url||null;return(0,d.jsxs)("footer",{className:"relative isolate overflow-hidden bg-[#0B0B0C] text-[#F7F2E8]",children:[(0,d.jsx)("div",{className:" pointer-events-none absolute bottom-[-180px] left-1/2 h-[360px] w-[90%] -translate-x-1/2 rounded-full bg-black/80 blur-[110px] "}),(0,d.jsxs)("div",{className:"relative mx-auto max-w-7xl px-6 pb-0 pt-20 md:pt-28",children:[(0,d.jsxs)("div",{className:"grid items-start gap-16 lg:grid-cols-12",children:[(0,d.jsxs)("div",{className:"lg:col-span-5",children:[(0,d.jsxs)("div",{className:"max-w-xl",children:[(0,d.jsxs)("div",{className:"mb-6 flex items-center gap-4",children:[(0,d.jsx)("div",{className:"h-[2px] w-12 bg-[#C9A227]"}),(0,d.jsx)("span",{className:"font-mono text-[11px] font-semibold uppercase tracking-[0.28em] text-[#C9A227]",children:"// Let's Collaborate"})]}),(0,d.jsxs)("h2",{className:"font-display text-4xl font-semibold leading-[1.05] tracking-tight text-[#F7F2E8] md:text-5xl lg:text-6xl",children:["Have a project",(0,d.jsx)("br",{}),(0,d.jsx)("span",{className:"text-[#C9A227]",children:"in mind?"})]}),(0,d.jsx)("p",{className:"mt-6 max-w-md text-base leading-7 text-[#F7F2E8]/55",children:"Tell us where your commerce operation is today, where it needs to go, and what is holding it back."})]}),(0,d.jsxs)("div",{className:"mt-9 flex flex-col items-start gap-3",children:[(0,d.jsxs)("a",{href:`mailto:${m}`,className:" group inline-flex items-center gap-3.5 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-3 text-sm font-semibold text-[#F7F2E8] backdrop-blur-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-[#C9A227]/50 hover:bg-[#C9A227] hover:text-[#0B0B0C] ",children:[(0,d.jsx)("span",{className:" flex h-9 w-9 items-center justify-center rounded-xl bg-[#C9A227]/10 text-[#C9A227] transition-colors group-hover:bg-black/10 group-hover:text-[#0B0B0C] ",children:(0,d.jsx)(g.A,{size:17})}),(0,d.jsx)("span",{children:m}),(0,d.jsx)(h.A,{size:14,className:" ml-2 opacity-50 transition-all group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:opacity-100 "})]}),(0,d.jsxs)("a",{href:`tel:${n.replace(/\s+/g,"")}`,className:" group inline-flex items-center gap-3.5 rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-3 text-sm font-semibold text-[#F7F2E8] backdrop-blur-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-[#C9A227]/50 hover:bg-[#C9A227] hover:text-[#0B0B0C] ",children:[(0,d.jsx)("span",{className:" flex h-9 w-9 items-center justify-center rounded-xl bg-[#C9A227]/10 text-[#C9A227] transition-colors group-hover:bg-black/10 group-hover:text-[#0B0B0C] ",children:(0,d.jsx)(i.A,{size:17})}),(0,d.jsx)("span",{children:n}),(0,d.jsx)(h.A,{size:14,className:" ml-2 opacity-50 transition-all group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:opacity-100 "})]})]})]}),(0,d.jsx)("div",{className:"lg:col-span-7",children:(0,d.jsxs)("div",{className:"grid gap-12 sm:grid-cols-2",children:[(0,d.jsxs)("div",{children:[p?(0,d.jsx)("img",{src:p,alt:"Tendrils",className:"h-10 w-auto max-w-[190px] object-contain"}):(0,d.jsxs)("p",{className:"font-display text-4xl font-semibold tracking-tight",children:["Tendril",(0,d.jsx)("span",{className:"text-[#C9A227]",children:"s"})]}),(0,d.jsx)("p",{className:"mt-5 max-w-sm text-sm leading-7 text-[#F7F2E8]/50",children:o}),l&&(0,d.jsxs)(j,{href:l.href,className:" mt-7 inline-flex items-center gap-2 rounded-full bg-[#C9A227] px-6 py-3 text-sm font-semibold text-[#0B0B0C] shadow-[0_10px_35px_rgba(201,162,39,0.18)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#F7F2E8] ",children:[(0,d.jsx)("span",{children:l.label||"Start a project"}),(0,d.jsx)(h.A,{size:16})]}),e.length>0&&(0,d.jsx)("div",{className:"mt-7 flex flex-wrap gap-2",children:e.map(a=>(0,d.jsx)(j,{href:a.url,className:" rounded-full border border-white/10 bg-white/[0.025] px-3.5 py-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#F7F2E8]/45 transition hover:border-[#C9A227]/50 hover:text-[#C9A227] ",children:a.platform},`${a.platform}-${a.url}`))})]}),c.length>0&&(0,d.jsx)("div",{className:"grid gap-10 sm:grid-cols-2",children:c.map(a=>(0,d.jsxs)("div",{children:[(0,d.jsx)("p",{className:"mb-5 text-[10px] font-bold uppercase tracking-[0.25em] text-[#C9A227]",children:a.title}),(0,d.jsx)("ul",{className:"space-y-3.5",children:a.links.map(a=>(0,d.jsx)("li",{children:(0,d.jsxs)(j,{href:a.href,className:" group inline-flex items-center gap-1.5 text-sm text-[#F7F2E8]/50 transition duration-300 hover:text-[#F7F2E8] ",children:[(0,d.jsx)("span",{children:a.label}),(0,d.jsx)(h.A,{size:11,className:" opacity-0 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:opacity-70 "})]})},`${a.label}-${a.href}`))})]},a.title))})]})})]}),(0,d.jsx)("div",{className:"relative mt-24 md:mt-28",children:(0,d.jsx)("div",{className:"relative flex items-center justify-center py-2",children:(0,d.jsx)("h3",{className:" pointer-events-none select-none whitespace-nowrap font-display text-[16vw] font-black uppercase leading-[0.85] tracking-[-0.075em] text-white/[0.045] md:text-[15vw] lg:text-[13.5vw] ",children:"TENDRILS"})})}),(0,d.jsxs)("div",{className:" relative z-10 flex flex-col gap-4 py-7 text-[11px] text-[#F7F2E8]/30 md:flex-row md:items-center md:justify-between ",children:[(0,d.jsxs)("p",{children:["\xa9 ",new Date().getFullYear()," Tendrils. All rights reserved."]}),(0,d.jsxs)("div",{className:"flex flex-wrap items-center gap-5",children:[(0,d.jsx)(f(),{href:"/privacy",className:"transition hover:text-[#F7F2E8]/70",children:"Privacy Policy"}),(0,d.jsx)(f(),{href:"/terms",className:"transition hover:text-[#F7F2E8]/70",children:"Terms of Service"}),e.slice(0,3).map(a=>(0,d.jsx)(j,{href:a.url,className:"transition hover:text-[#F7F2E8]/70",children:a.platform},`bottom-${a.platform}`))]})]})]})]})}},21874:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,81170,23)),Promise.resolve().then(c.t.bind(c,23597,23)),Promise.resolve().then(c.t.bind(c,36893,23)),Promise.resolve().then(c.t.bind(c,89748,23)),Promise.resolve().then(c.t.bind(c,6060,23)),Promise.resolve().then(c.t.bind(c,7184,23)),Promise.resolve().then(c.t.bind(c,69576,23)),Promise.resolve().then(c.t.bind(c,73041,23)),Promise.resolve().then(c.t.bind(c,51384,23))},42247:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(97954).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\tendril_site_shree_updated_02\\\\src\\\\components\\\\layout\\\\MobileNav.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\tendril_site_shree_updated_02\\src\\components\\layout\\MobileNav.jsx","default")},45434:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,54160,23)),Promise.resolve().then(c.t.bind(c,31603,23)),Promise.resolve().then(c.t.bind(c,68495,23)),Promise.resolve().then(c.t.bind(c,75170,23)),Promise.resolve().then(c.t.bind(c,77526,23)),Promise.resolve().then(c.t.bind(c,78922,23)),Promise.resolve().then(c.t.bind(c,29234,23)),Promise.resolve().then(c.t.bind(c,12263,23)),Promise.resolve().then(c.bind(c,82146))},46351:(a,b,c)=>{Promise.resolve().then(c.bind(c,94525)),Promise.resolve().then(c.t.bind(c,69389,23)),Promise.resolve().then(c.t.bind(c,63112,23)),Promise.resolve().then(c.bind(c,49328)),Promise.resolve().then(c.bind(c,72425)),Promise.resolve().then(c.bind(c,42247))},49328:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(97954).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\tendril_site_shree_updated_02\\\\src\\\\components\\\\layout\\\\FloatingNavbar.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\tendril_site_shree_updated_02\\src\\components\\layout\\FloatingNavbar.jsx","default")},52712:(a,b,c)=>{"use strict";c.d(b,{S:()=>d});let d=(0,c(13632).UU)({projectId:"zggcyoyq",dataset:"production",apiVersion:"2024-08-01",useCdn:!1,perspective:"published"})},60833:(a,b,c)=>{"use strict";c.d(b,{default:()=>m});var d=c(21124),e=c(3991),f=c.n(e),g=c(79002),h=c(38301),i=c(47089);let j=(0,c(18610).vt)(a=>({isMobileNavOpen:!1,openMobileNav:()=>a({isMobileNavOpen:!0}),closeMobileNav:()=>a({isMobileNavOpen:!1})}));var k=c(93313);let l=[{label:"Services",href:"/services"},{label:"Industries",href:"/industries"},{label:"Solutions",href:"/solutions"},{label:"Case Studies",href:"/case-studies"},{label:"About Us",href:"/about"},{label:"Contact",href:"/contact"}];function m({settings:a}){let b=a?.headerLogo?.assetUrl||a?.headerLogoDark?.assetUrl||a?.headerLogoLight?.assetUrl,c=j(a=>a.isMobileNavOpen),e=j(a=>a.closeMobileNav),m=a?.navLinks?.length?a.navLinks:l,n=(m.some(a=>"about us"===String(a?.label||"").toLowerCase())?m:[...m,{label:"About Us",href:"/about"}]).filter(a=>"resources"!==String(a?.label||"").toLowerCase()),o=(0,k.Y)(a=>a.services),p=(0,k.Y)(a=>a.industries),q=(0,k.Y)(a=>a.solutions),[r,s]=(0,h.useState)(!1),[t,u]=(0,h.useState)(!1),[v,w]=(0,h.useState)(!1);return(0,d.jsxs)(g.P.div,{initial:!1,animate:{x:c?0:"100%"},transition:{duration:.45,ease:[.22,1,.36,1]},className:"fixed inset-0 z-[60] bg-ivory px-8 py-8 md:hidden overflow-y-auto","aria-hidden":!c,children:[(0,d.jsxs)("div",{className:"flex items-center justify-between",children:[(0,d.jsx)(f(),{href:"/",onClick:e,className:"flex items-center","aria-label":"Tendrils home",children:b?(0,d.jsx)("img",{src:b,alt:a?.headerLogoAlt||"Tendrils",className:"h-8 w-auto object-contain"}):(0,d.jsx)("span",{className:"font-display text-2xl text-black",children:"Tendrils"})}),(0,d.jsx)("button",{onClick:e,"aria-label":"Close menu",children:(0,d.jsx)(i.A,{})})]}),(0,d.jsxs)("nav",{className:"mt-12 flex flex-col gap-6 pb-16",children:[n.map(a=>{let b=String(a.label).toLowerCase();return"services"===b?(0,d.jsxs)("div",{children:[(0,d.jsxs)("button",{onClick:()=>s(a=>!a),className:"flex w-full items-center justify-between font-display text-4xl text-left",children:[a.label,(0,d.jsx)("span",{className:`text-2xl transition ${r?"rotate-180 text-gold-deep":""}`,children:"⌄"})]}),r&&(0,d.jsxs)("div",{className:"mt-4 space-y-3 border-l border-gold/30 pl-5",children:[o.map(a=>{let b="string"==typeof a?.slug?a.slug:a?.slug?.current;return(0,d.jsxs)("div",{children:[(0,d.jsx)(f(),{href:`/services/${b}`,onClick:e,className:"block text-lg text-ink/65",children:a.name||a.title}),a.children?.map(a=>(0,d.jsxs)(f(),{href:`/services/${b}/${a.slug}`,onClick:e,className:"ml-4 mt-2 block text-sm text-ink/45",children:["↳ ",a.name]},a._id))]},a._id||b)}),(0,d.jsx)(f(),{href:"/services",onClick:e,className:"block text-sm font-semibold text-gold-deep pt-1",children:"View all services →"})]})]},`${a.label}-${a.href}`):"industries"===b?(0,d.jsxs)("div",{children:[(0,d.jsxs)("button",{onClick:()=>u(a=>!a),className:"flex w-full items-center justify-between font-display text-4xl text-left",children:[a.label,(0,d.jsx)("span",{className:`text-2xl transition ${t?"rotate-180 text-gold-deep":""}`,children:"⌄"})]}),t&&(0,d.jsxs)("div",{className:"mt-4 space-y-3 border-l border-gold/30 pl-5",children:[p.map(a=>{let b="string"==typeof a?.slug?a.slug:a?.slug?.current;return(0,d.jsxs)("div",{children:[(0,d.jsx)(f(),{href:`/industries/${b}`,onClick:e,className:"block text-lg text-ink/65",children:a.title||a.name}),a.children?.map(a=>(0,d.jsxs)(f(),{href:`/industries/${b}/${a.slug}`,onClick:e,className:"ml-4 mt-2 block text-sm text-ink/45",children:["↳ ",a.title]},a._id))]},a._id||b)}),(0,d.jsx)(f(),{href:"/industries",onClick:e,className:"block text-sm font-semibold text-gold-deep pt-1",children:"View all industries →"})]})]},`${a.label}-${a.href}`):"solutions"===b?(0,d.jsxs)("div",{children:[(0,d.jsxs)("button",{onClick:()=>w(a=>!a),className:"flex w-full items-center justify-between font-display text-4xl text-left",children:[a.label,(0,d.jsx)("span",{className:`text-2xl transition ${v?"rotate-180 text-gold-deep":""}`,children:"⌄"})]}),v&&(0,d.jsxs)("div",{className:"mt-4 space-y-3 border-l border-gold/30 pl-5",children:[q.map(a=>{let b="string"==typeof a?.slug?a.slug:a?.slug?.current;return(0,d.jsxs)("div",{children:[(0,d.jsx)(f(),{href:`/solutions/${b}`,onClick:e,className:"block text-lg text-ink/65",children:a.title}),a.children?.map(a=>(0,d.jsxs)(f(),{href:`/solutions/${b}/${a.slug}`,onClick:e,className:"ml-4 mt-2 block text-sm text-ink/45",children:["↳ ",a.title]},a._id))]},a._id||b)}),(0,d.jsx)(f(),{href:"/solutions",onClick:e,className:"block text-sm font-semibold text-gold-deep pt-1",children:"View all solutions →"})]})]},`${a.label}-${a.href}`):(0,d.jsx)(f(),{href:a.href,onClick:e,className:"font-display text-4xl",children:a.label},`${a.label}-${a.href}`)}),(0,d.jsx)(f(),{href:"/contact",onClick:e,className:"mt-4 inline-flex w-fit rounded-full bg-gold px-6 py-3 font-semibold text-ink",children:"Book a Consultation"})]})]})}},61135:()=>{},61307:()=>{},65698:(a,b,c)=>{"use strict";c.d(b,{default:()=>J});var d=c(21124),e=c(3991),f=c.n(e),g=c(38301),h=c(25463),i=c(34341),j=c(85607),k=c(79002),l=c(85351),m=c(47089),n=c(88285),o=c(6130),p=c(46267),q=c(59405);let r=[{key:"build",name:"Build",subtitle:"Foundation"},{key:"automate",name:"Automate",subtitle:"Workflows"},{key:"scale",name:"Scale",subtitle:"Infrastructure"},{key:"grow",name:"Grow",subtitle:"Acquisition"},{key:"support",name:"Support",subtitle:"Optimization"}];function s(a=""){return String(a).replace(/[_-]+/g," ").replace(/\s+/g," ").trim()}function t(a){return a?"string"==typeof a.slug?a.slug:a.slug&&"object"==typeof a.slug&&a.slug.current||"":""}function u(a,b=""){let c=t(a);return c?b?`${b}/${c}`:`/services/${c}`:b||"/services"}function v({services:a=[],onNavigate:b}){let c=(0,g.useMemo)(()=>{let b={build:[],automate:[],scale:[],grow:[],support:[]};return a.forEach(a=>{let c=String(a?.pillar||"").trim().toLowerCase();b[c]&&b[c].push(a)}),Object.keys(b).forEach(a=>{b[a].sort((a,b)=>(a.order??9999)-(b.order??9999))}),b},[a]),e=r.find(a=>c[a.key]?.length)?.key||"build",[h,i]=(0,g.useState)(e),j=c[h]||[],[l,m]=(0,g.useState)(null),n=j.find(a=>a._id===l)||j[0]||null,o=n?.children||[],v=n?u(n):"/services";return(0,d.jsx)(k.P.div,{initial:{opacity:0,y:10,scale:.98},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:8,scale:.98},transition:{duration:.22,ease:"easeOut"},className:"   w-full     ",children:(0,d.jsxs)("div",{className:"   overflow-hidden   rounded-[28px]   border   border-[#111111]/10   bg-[#F7F2E8]   shadow-[0_25px_80px_rgba(0,0,0,0.18)]   backdrop-blur-2xl   ",children:[(0,d.jsxs)("div",{className:"   grid   grid-cols-[255px_315px_minmax(0,1fr)]   min-h-[440px]   ",children:[(0,d.jsxs)("div",{className:"   m-5   flex   flex-col   rounded-[22px]   bg-[#111111]   p-6   text-[#F7F2E8]   ",children:[(0,d.jsx)("div",{children:(0,d.jsx)("p",{className:"   text-[10px]   font-bold   uppercase   tracking-[0.28em]   text-[#C9A227]   ",children:"Service Pillars"})}),(0,d.jsx)("div",{className:"mt-6 space-y-1",children:r.map((a,b)=>{let e=c[a.key]?.length||0,f=h===a.key;return(0,d.jsxs)("button",{type:"button",onMouseEnter:()=>{i(a.key),m(null)},className:`
                        group
                        flex
                        w-full
                        items-center
                        justify-between
                        rounded-[16px]
                        px-5
                        py-4
                        text-left
                        transition-all
                        duration-200
                        ${f?"bg-[#C9A24F] text-[#111111]":"text-[#F7F2E8] hover:bg-white/10"}
                      `,children:[(0,d.jsxs)("div",{children:[(0,d.jsx)("p",{className:"   text-[15px]   font-semibold   capitalize   ",children:a.name}),(0,d.jsx)("p",{className:`
                            mt-0.5
                            text-[9px]
                            uppercase
                            tracking-[0.12em]
                            ${f?"text-[#111111]/60":"text-white/40"}
                          `,children:a.subtitle})]}),(0,d.jsx)("span",{className:`
                          font-mono
                          text-[10px]
                          ${f?"text-[#111111]":"text-white/45"}
                        `,children:String(e).padStart(2,"0")})]},a.key)})}),(0,d.jsxs)(f(),{href:"/services",onClick:b,className:"   mt-auto   flex   items-center   gap-2   border-t   border-white/10   pt-5   text-xs   font-semibold   text-[#C9A227]   transition-colors   hover:text-white   ",children:["View all services",(0,d.jsx)(p.A,{className:"h-3.5 w-3.5"})]})]}),(0,d.jsxs)("div",{className:"   border-r   border-[#111111]/10   px-6   py-8   ",children:[(0,d.jsxs)("div",{className:"mb-5",children:[(0,d.jsx)("p",{className:"   text-[10px]   font-bold   uppercase   tracking-[0.24em]   text-[#9A7625]   ",children:r.find(a=>a.key===h)?.name}),(0,d.jsx)("p",{className:"   mt-1   text-[11px]   text-[#111111]/40   ",children:"Services"})]}),0===j.length?(0,d.jsx)("div",{className:"py-8",children:(0,d.jsx)("p",{className:"text-sm text-[#111111]/35",children:"No services available."})}):(0,d.jsx)("div",{className:"space-y-1",children:j.map(a=>{let c=t(a);if(!c)return null;let e=n?._id===a._id,g=Array.isArray(a.children)&&a.children.length>0;return(0,d.jsxs)(f(),{href:u(a),onMouseEnter:()=>m(a._id),onClick:b,className:`
                          group
                          flex
                          items-center
                          justify-between
                          rounded-[16px]
                          px-4
                          py-3
                          transition-all
                          duration-200
                          ${e?"bg-white shadow-[0_5px_20px_rgba(0,0,0,0.06)]":"hover:bg-white/60"}
                        `,children:[(0,d.jsxs)("div",{className:"min-w-0",children:[(0,d.jsx)("p",{className:`
                              truncate
                              text-[13px]
                              font-semibold
                              ${e?"text-[#111111]":"text-[#111111]/65"}
                            `,children:s(a.title||a.name)}),a.shortDescription&&(0,d.jsx)("p",{className:"   mt-1   line-clamp-1   text-[10px]   text-[#111111]/35   ",children:a.shortDescription})]}),g?(0,d.jsx)(q.A,{className:`
                              ml-3
                              h-4
                              w-4
                              shrink-0
                              ${e?"text-[#C9A227]":"text-[#111111]/25"}
                            `}):(0,d.jsx)(p.A,{className:"   ml-3   h-3.5   w-3.5   shrink-0   text-[#C9A227]   opacity-0   transition   group-hover:opacity-100   "})]},a._id||c)})})]}),(0,d.jsx)("div",{className:"   min-w-0   px-7   py-8   ",children:n?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsxs)("div",{className:"   border-b   border-[#111111]/10   pb-5   ",children:[(0,d.jsx)("p",{className:"   text-[9px]   font-bold   uppercase   tracking-[0.24em]   text-[#9A7625]   ",children:r.find(a=>a.key===h)?.name}),(0,d.jsx)("h3",{className:"   mt-2   font-display   text-[28px]   leading-tight   text-[#111111]   ",children:s(n.title||n.name)}),n.shortDescription&&(0,d.jsx)("p",{className:"   mt-2   max-w-xl   text-[12px]   leading-5   text-[#111111]/45   ",children:n.shortDescription})]}),o.length>0?(0,d.jsxs)("div",{className:"pt-5",children:[(0,d.jsx)("p",{className:"   mb-3   text-[9px]   font-bold   uppercase   tracking-[0.2em]   text-[#111111]/35   ",children:"Explore"}),(0,d.jsx)("div",{className:"space-y-1",children:o.map(a=>{let c=t(a);if(!c)return null;let e=u(a,v),g=Array.isArray(a.children)&&a.children.length>0;return(0,d.jsxs)(f(),{href:e,onClick:b,className:"   group   flex   items-center   justify-between   rounded-xl   px-4   py-3   transition-all   hover:bg-white   ",children:[(0,d.jsxs)("div",{children:[(0,d.jsx)("p",{className:"   text-[13px]   font-medium   text-[#111111]/70   group-hover:text-[#111111]   ",children:s(a.title||a.name)}),a.shortDescription&&(0,d.jsx)("p",{className:"   mt-1   line-clamp-1   text-[10px]   text-[#111111]/35   ",children:a.shortDescription}),g&&(0,d.jsxs)("p",{className:"   mt-1.5   text-[9px]   font-semibold   uppercase   tracking-[0.12em]   text-[#C9A227]   ",children:[a.children.length," ","sub-services"]})]}),(0,d.jsx)(p.A,{className:"   h-3.5   w-3.5   shrink-0   text-[#C9A227]   opacity-0   transition   group-hover:opacity-100   "})]},a._id||c)})})]}):(0,d.jsxs)("div",{className:"pt-7",children:[(0,d.jsx)("p",{className:"   text-[12px]   leading-5   text-[#111111]/40   ",children:"This service doesn't have any child services yet."}),(0,d.jsxs)(f(),{href:v,onClick:b,className:"   mt-4   inline-flex   items-center   gap-2   text-[10px]   font-bold   uppercase   tracking-[0.15em]   text-[#9A7625]   hover:text-[#111111]   ",children:["View service",(0,d.jsx)(p.A,{className:"h-3.5 w-3.5"})]})]})]}):(0,d.jsx)("div",{className:"flex h-full items-center",children:(0,d.jsx)("p",{className:"text-sm text-[#111111]/35",children:"Select a service."})})})]}),(0,d.jsxs)("div",{className:"   flex   items-center   justify-between   border-t   border-[#111111]/10   bg-white/30   px-6   py-3   ",children:[(0,d.jsx)("p",{className:"   text-[9px]   uppercase   tracking-[0.18em]   text-[#111111]/35   ",children:"Commerce Architecture • Growth • Operations"}),(0,d.jsx)(f(),{href:"/services",onClick:b,className:"   text-[10px]   font-semibold   uppercase   tracking-[0.15em]   text-[#9A7625]   hover:text-[#111111]   ",children:"Explore all →"})]})]})})}function w({industries:a=[],loaded:b=!1,onClose:c}){return(0,d.jsxs)(k.P.div,{initial:{opacity:0,y:10,scale:.98},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:8,scale:.98},transition:{duration:.22,ease:"easeOut"},onMouseLeave:c,className:"   w-full   overflow-hidden   rounded-[28px]   border   border-gold/20   bg-ivory/95   backdrop-blur-2xl   shadow-[0_24px_70px_rgba(0,0,0,0.18)]   ",children:[(0,d.jsxs)("div",{className:"grid grid-cols-[225px_minmax(0,1fr)] gap-7 p-6",children:[(0,d.jsxs)("div",{className:"   flex   min-h-[330px]   flex-col   rounded-[22px]   bg-ink   p-6   text-ivory   ",children:[(0,d.jsx)("p",{className:"   text-[10px]   font-bold   uppercase   tracking-[0.28em]   text-gold   ",children:"Tendrils Industries"}),(0,d.jsxs)("h3",{className:"   mt-5   font-display   text-[26px]   leading-[1.05]   tracking-tight   ",children:["Commerce",(0,d.jsx)("br",{}),"shaped around",(0,d.jsx)("br",{}),"your industry."]}),(0,d.jsx)("p",{className:"   mt-5   text-[12px]   leading-5   text-white/55   ",children:"Every industry has different customers, operations, systems and growth constraints. We architect around those realities."}),(0,d.jsxs)(f(),{href:"/industries",onClick:c,className:"   mt-auto   inline-flex   items-center   gap-2   text-xs   font-semibold   text-gold-light   transition-colors   hover:text-gold   ",children:["Explore all industries",(0,d.jsx)(p.A,{className:"h-3.5 w-3.5"})]})]}),(0,d.jsx)("div",{className:"min-w-0",children:b?0===a.length?(0,d.jsx)(y,{}):(0,d.jsx)("div",{className:"   grid   grid-cols-1   gap-2   sm:grid-cols-2   ",children:a.map((a,b)=>{let e="string"==typeof a?.slug?a.slug:a?.slug?.current;return e?(0,d.jsxs)(f(),{href:`/industries/${e}`,onClick:c,className:"   group   relative   overflow-hidden   rounded-2xl   border   border-transparent   px-4   py-4   transition-all   duration-300   hover:border-gold/15   hover:bg-white   hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)]   ",children:[(0,d.jsx)("span",{className:"   absolute   left-0   top-0   h-full   w-[2px]   origin-top   scale-y-0   bg-gold   transition-transform   duration-300   group-hover:scale-y-100   "}),(0,d.jsxs)("div",{className:"   flex   items-start   justify-between   gap-4   ",children:[(0,d.jsxs)("div",{className:"min-w-0",children:[(0,d.jsx)("p",{className:"   text-[13px]   font-semibold   text-ink/80   transition-colors   group-hover:text-ink   ",children:function(a=""){return String(a).replace(/[_-]+/g," ").replace(/\s+/g," ").trim()}(a.title||a.name)}),a.shortDescription&&(0,d.jsx)("p",{className:"   mt-1.5   line-clamp-2   text-[10px]   leading-4   text-ink/45   ",children:a.shortDescription})]}),(0,d.jsx)(p.A,{className:"   mt-0.5   h-3.5   w-3.5   shrink-0   text-gold-deep   opacity-0   -translate-x-1   transition-all   duration-200   group-hover:translate-x-0   group-hover:opacity-100   "})]})]},a?._id||e):null})}):(0,d.jsx)(x,{})})]}),b&&a.length>0&&(0,d.jsxs)("div",{className:"   flex   items-center   justify-between   border-t   border-ink/5   bg-ivory/50   px-6   py-3   ",children:[(0,d.jsx)("p",{className:"   text-[10px]   uppercase   tracking-[0.18em]   text-ink/35   ",children:"Industry intelligence • Commerce • Growth"}),(0,d.jsx)(f(),{href:"/industries",onClick:c,className:"   text-[10px]   font-semibold   uppercase   tracking-[0.15em]   text-gold-deep   transition-colors   hover:text-ink   ",children:"View all →"})]})]})}function x(){return(0,d.jsx)("div",{className:"grid grid-cols-2 gap-4",children:[1,2,3,4,5,6].map(a=>(0,d.jsxs)("div",{className:"animate-pulse rounded-2xl bg-white p-5",children:[(0,d.jsx)("div",{className:"h-3 w-28 rounded bg-ink/10"}),(0,d.jsx)("div",{className:"mt-3 h-2 w-full rounded bg-ink/5"}),(0,d.jsx)("div",{className:"mt-2 h-2 w-3/4 rounded bg-ink/5"})]},a))})}function y(){return(0,d.jsx)("div",{className:"   flex   min-h-[250px]   items-center   justify-center   ",children:(0,d.jsxs)("div",{className:"text-center",children:[(0,d.jsx)("p",{className:"   font-display   text-xl   text-ink   ",children:"Industries coming soon."}),(0,d.jsx)("p",{className:"   mt-2   text-xs   text-ink/45   ",children:"Add industries from Sanity Studio to populate this menu."})]})})}function z({solutions:a=[],loaded:b=!1,onClose:c}){return(0,d.jsxs)(k.P.div,{initial:{opacity:0,y:10,scale:.98},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:8,scale:.98},transition:{duration:.22},onMouseLeave:c,className:"w-full overflow-hidden rounded-[28px] border border-gold/20 bg-ivory/95 backdrop-blur-2xl shadow-[0_24px_70px_rgba(0,0,0,.18)]",children:[(0,d.jsxs)("div",{className:"grid grid-cols-[225px_minmax(0,1fr)] gap-7 p-6",children:[(0,d.jsxs)("div",{className:"flex min-h-[300px] flex-col rounded-[22px] bg-ink p-6 text-ivory",children:[(0,d.jsx)("p",{className:"text-[10px] font-bold uppercase tracking-[.28em] text-gold",children:"Tendrils Solutions"}),(0,d.jsxs)("h3",{className:"mt-5 font-display text-[26px] leading-[1.05]",children:["Solve the system.",(0,d.jsx)("br",{}),"Build for what’s next."]}),(0,d.jsx)("p",{className:"mt-5 text-[12px] leading-5 text-white/55",children:"Composable solutions for migrations, integrations, headless commerce, multi-store operations and the workflows between them."}),(0,d.jsxs)(f(),{href:"/solutions",onClick:c,className:"mt-auto inline-flex items-center gap-2 text-xs font-semibold text-gold-light",children:["Explore all solutions ",(0,d.jsx)(p.A,{className:"h-3.5 w-3.5"})]})]}),(0,d.jsx)("div",{children:b?0===a.length?(0,d.jsx)("p",{className:"p-8 text-sm text-ink/40",children:"No solutions published yet."}):(0,d.jsx)("div",{className:"grid gap-2 sm:grid-cols-2",children:a.map(a=>(0,d.jsxs)(f(),{href:`/solutions/${a.slug}`,onClick:c,className:"group rounded-2xl px-4 py-4 hover:bg-white",children:[(0,d.jsx)("p",{className:"text-[13px] font-semibold",children:a.title}),(0,d.jsxs)("p",{className:"mt-1.5 line-clamp-2 text-[10px] leading-4 text-ink/45",children:[a.category,a.category&&a.shortDescription?" \xb7 ":"",a.shortDescription]})]},a._id||a.slug))}):(0,d.jsx)("p",{className:"p-8 text-sm text-ink/40",children:"Loading solutions…"})})]}),(0,d.jsxs)("div",{className:"flex items-center justify-between border-t border-ink/5 px-6 py-3",children:[(0,d.jsx)("p",{className:"text-[10px] uppercase tracking-[.18em] text-ink/35",children:"Solutions • Systems • Integrations • Growth"}),(0,d.jsx)(f(),{href:"/solutions",onClick:c,className:"text-[10px] font-semibold uppercase tracking-[.15em] text-gold-deep",children:"View all →"})]})]})}let A={service:"Service",industry:"Industry",solution:"Solution",caseStudy:"Case Study"};function B({open:a,onClose:b}){let[c,e]=(0,g.useState)(""),[f,h]=(0,g.useState)([]),[i,l]=(0,g.useState)(!1),o=(0,g.useRef)(null);(0,g.useRef)(null);let p=c.trim();return(0,d.jsx)(j.N,{children:a&&(0,d.jsx)(k.P.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:.2},className:"fixed inset-0 z-[9999] flex items-start justify-center bg-black/35 px-4 backdrop-blur-xl",onMouseDown:a=>{a.target===a.currentTarget&&b()},children:(0,d.jsxs)(k.P.div,{initial:{opacity:0,y:25,scale:.97},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:15,scale:.98},transition:{duration:.25,ease:"easeOut"},className:"mt-[18vh] w-[min(820px,100%)]",children:[(0,d.jsxs)("div",{className:"mb-4 flex items-center justify-between px-2",children:[(0,d.jsx)("p",{className:"text-[10px] font-semibold uppercase tracking-[0.25em] text-white/60",children:"Search Tendrils"}),(0,d.jsxs)("button",{type:"button",onClick:b,className:"flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.15em] text-white/60 transition-colors hover:text-white",children:["ESC",(0,d.jsx)(m.A,{className:"h-3.5 w-3.5"})]})]}),(0,d.jsxs)("div",{className:"relative overflow-hidden rounded-[22px] border border-black/10 bg-[#F7F2E8] shadow-[0_30px_100px_rgba(0,0,0,0.35)]",children:[(0,d.jsxs)("div",{className:"flex items-center",children:[(0,d.jsx)(n.A,{className:"ml-6 h-6 w-6 shrink-0 text-[#111111]",strokeWidth:1.8}),(0,d.jsx)("input",{ref:o,type:"text",value:c,onChange:a=>e(a.target.value),placeholder:"Search services, industries, solutions, case studies...",autoComplete:"off",className:"h-[76px] w-full bg-transparent px-5 text-[18px] font-medium text-[#111111] outline-none placeholder:text-[#111111]/35"}),c&&(0,d.jsx)("button",{type:"button",onClick:()=>e(""),"aria-label":"Clear search",className:"mr-5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-black/5 text-[#111111]/60 transition hover:bg-black/10 hover:text-[#111111]",children:(0,d.jsx)(m.A,{className:"h-4 w-4"})})]}),p&&(0,d.jsx)("div",{className:"border-t border-black/10 px-3 py-3",children:(0,d.jsx)(C,{query:p,results:f,loading:i,onClose:b})})]}),!p&&(0,d.jsx)("div",{className:"mt-4 flex justify-center text-[10px] uppercase tracking-[0.18em] text-white/45",children:"Search across services, industries, solutions & case studies"})]})})})}function C({query:a,results:b,loading:c,onClose:e}){return c?(0,d.jsxs)("div",{className:"px-4 py-8 text-center",children:[(0,d.jsx)("div",{className:"mx-auto h-5 w-5 animate-spin rounded-full border-2 border-black/10 border-t-[#C5A05A]"}),(0,d.jsxs)("p",{className:"mt-3 text-[11px] text-[#111111]/40",children:["Searching for “",a,"”..."]})]}):0===b.length?(0,d.jsxs)("div",{className:"px-4 py-8 text-center",children:[(0,d.jsx)("p",{className:"font-display text-lg text-[#111111]",children:"No results found"}),(0,d.jsx)("p",{className:"mt-1 text-xs text-[#111111]/40",children:"Try a service, industry, solution, or case study name."})]}):(0,d.jsxs)("div",{className:"max-h-[min(58vh,520px)] overflow-y-auto pr-1",children:[(0,d.jsxs)("div",{className:"mb-2 px-4 pt-1 text-[9px] font-bold uppercase tracking-[0.22em] text-[#111111]/35",children:[b.length," result",1===b.length?"":"s"]}),(0,d.jsx)("div",{className:"space-y-1",children:b.map(a=>(0,d.jsxs)(f(),{href:a.href,onClick:e,className:"group flex items-center justify-between rounded-[16px] px-4 py-3.5 transition hover:bg-white",children:[(0,d.jsxs)("div",{className:"min-w-0",children:[(0,d.jsx)("p",{className:"text-[13px] font-semibold text-[#111111]",children:a.title}),(0,d.jsx)("p",{className:"mt-1 text-[10px] uppercase tracking-[0.12em] text-[#9A7625]",children:A[a.type]||a.type}),a.shortDescription&&(0,d.jsx)("p",{className:"mt-1 line-clamp-2 text-[11px] leading-4 text-[#111111]/45",children:a.shortDescription})]}),(0,d.jsx)(p.A,{className:"ml-4 h-4 w-4 shrink-0 text-[#C9A227] opacity-0 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:opacity-100"})]},a._id))})]})}c(52712);var D=c(23178);let E=`{
  ...,
  "assetUrl": coalesce(asset->url, url)
}`,F=`{
  _id,
  _type,
  "slug": slug.current,
  "parent": parent->{
    "slug": slug.current,
    "parent": parent->{
      "slug": slug.current,
      "parent": parent->{
        "slug": slug.current
      }
    }
  }
}`;(0,D.A)`
  *[_type == "vendor"] | order(order asc, name asc){
    _id,
    name,
    category,
    url,
    "imageUrl": coalesce(logo.asset->url, logo.assetUrl),
    logo ${E}
  }
`,(0,D.A)`
  *[_type == "homepage"][0]{
    title,

    hero{
      eyebrow,
      headline,
      highlight,
      description,

      "imageUrl": coalesce(image.asset->url, heroImage.asset->url, image.assetUrl),
      image ${E},
      heroImage ${E},

      primaryCta{label, href, page->${F}},
      secondaryCta{label, href, page->${F}}
    },

    stats[]{
      value,
      label,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E}
    },

    partnersMarquee{
      label,
      partners[]{
        name,
        url,
        "imageUrl": coalesce(logo.asset->url, image.asset->url),
        logo ${E}
      }
    },

    marketingGrid[]{
      key,
      title,
      description,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E}
    },

    vendorsSection{
      eyebrow,
      title,
      subtitle,
      items[]->{
        _id, name, category, url,
        "imageUrl": coalesce(logo.asset->url, logo.assetUrl),
        logo ${E}
      }
    },

    "testimonials": coalesce(
      testimonials[]->{
        _id,
        quote,
        name,
        title,
        company,
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      },
      []
    ),

    expertise{
      title,
      subtitle,

      items[]{
        heading,
        description,
        "imageUrl": coalesce(image.asset->url, heroImage.asset->url),
        image ${E},
        cta{label, href}
      }
    },

    industriesSection{
      eyebrow,
      title,
      subtitle,
      cta{label, href},
      items[]->{
        _id,
        title,
        "slug": slug.current,
        category,
        shortDescription,
        "imageUrl": coalesce(homeImage.asset->url, hero.image.asset->url, image.asset->url),
        homeImage ${E},
        image ${E}
      }
    },

    solutionsSection{
      eyebrow,
      title,
      subtitle,
      cta{label, href},
      items[]->{
        _id,
        title,
        "slug": slug.current,
        category,
        shortDescription,
        summary,
        "imageUrl": coalesce(homeImage.asset->url, hero.image.asset->url, image.asset->url),
        homeImage ${E},
        image ${E}
      }
    },

    whyChooseUs{
      title,
      subtitle,
      features[]{
        title,
        description,
        "imageUrl": coalesce(image.asset->url, heroImage.asset->url),
        image ${E},
        cta{label, href}
      }
    },

    sections[]{
      ...,
      cta{..., page->${F}},
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E},

      items[]{
        ...,
        cta{..., page->${F}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      },

      cards[]{
        ...,
        cta{..., page->${F}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      },

      steps[]{
        ...,
        cta{..., page->${F}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      },

      members[]{
        ...,
        "imageUrl": coalesce(image.asset->url, photo.asset->url),
        image ${E}
      },

      partners[]{
        ...,
        "imageUrl": coalesce(image.asset->url, logo.asset->url),
        image ${E}
      },

      testimonials[]->{
        _id,
        quote,
        name,
        title,
        company,
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      }
    },

    finalCta{
      eyebrow,
      title,
      description,
      cta{label, href, page->${F}}
    }
  }
`,(0,D.A)`
  *[_type == "service"] | order(coalesce(order, 9999) asc, name asc) {
    _id,
    name,
    "slug": slug.current,
    pillar,
    shortDescription,
    description,
    featured,
    order,

    parentService->{
      _id,
      name,
      "slug": slug.current
    },

    parentId,
    "imageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),
    "heroImage": coalesce(hero.image, heroImage, image) ${E},
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url)
  }
`,(0,D.A)`
  *[
    _type == "service" &&
    slug.current == $slug
  ][0]{
    _id,
    name,
    "slug": slug.current,
    pillar,
    shortDescription,
    description,
    order,
    featured,
    pageStyle,

    // Root level image fallbacks
    "imageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),
    image ${E},

    hero{
      eyebrow,
      headline,
      highlight,
      description,
      "imageUrl": coalesce(image.asset->url, heroImage.asset->url, asset->url),
      image ${E},
      heroImage ${E},

      primaryCta{
        label,
        href,
        page->{
          _type,
          _id,
          "slug": slug.current
        }
      },

      secondaryCta{
        label,
        href,
        page->{
          _type,
          _id,
          "slug": slug.current
        }
      }
    },

    stats[]{
      ...,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E}
    },

    sections[]{
      ...,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E},

      items[]{
        ...,
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      },

      cards[]{
        ...,
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      }
    },

    "parent": parent->{
      _id,
      name,
      "slug": slug.current
    },

    "children": *[
      _type == "service" &&
      parent._ref == ^._id &&
      defined(slug.current)
    ] | order(coalesce(order, 9999) asc, name asc) {
      _id,
      name,
      "slug": slug.current,
      shortDescription
    },

    "relatedServices": relatedServices[]->{
      _id,
      name,
      "slug": slug.current,
      pillar,
      shortDescription
    },

    "industries": industries[]->{
      _id,
      title,
      "slug": slug.current
    },

    seo{
      title,
      description,
      metaTitle,
      metaDescription,
      "ogImage": ogImage ${E},
      noIndex
    }
  }
`,(0,D.A)`
  *[
    _type == "service" &&
    defined(slug.current)
  ] | order(coalesce(order, 9999) asc, name asc) {
    _id,
    name,
    "slug": slug.current,
    "parentId": parent._ref,
    order
  }
`,(0,D.A)`
  *[
    _type == "service" &&
    defined(slug.current) &&
    !defined(parent._ref)
  ] | order(coalesce(order, 9999) asc, name asc) {
    _id,
    name,
    "slug": slug.current,
    pillar,
    shortDescription,
    order,

    "children": *[
      _type == "service" &&
      parent._ref == ^._id &&
      defined(slug.current)
    ] | order(coalesce(order, 9999) asc, name asc) {
      _id,
      name,
      "slug": slug.current,
      pillar,
      shortDescription,
      order,

      "children": *[
        _type == "service" &&
        parent._ref == ^._id &&
        defined(slug.current)
      ] | order(coalesce(order, 9999) asc, name asc) {
        _id,
        name,
        "slug": slug.current,
        pillar,
        shortDescription,
        order
      }
    }
  }
`,(0,D.A)`
  *[
    _type == "solution" &&
    defined(slug.current) &&
    !defined(parent._ref)
  ] | order(coalesce(order, 9999) asc, title asc) {
    _id,
    title,
    "slug": slug.current,
    "parentId": parent._ref,
    category,
    shortDescription,
    featured,
    "children": *[_type == "solution" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, shortDescription, featured,
      "children": *[_type == "solution" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
        _id, title, "slug": slug.current, shortDescription
      }
    },
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url)
  }
`,(0,D.A)`
  *[
    _type == "solution" &&
    defined(slug.current)
  ] | order(featured desc, coalesce(order, 9999) asc, title asc) {
    _id,
    title,
    "slug": slug.current,
    category,
    shortDescription,
    summary,
    featured,
    pageStyle,
    integrations,
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url, mainImage.asset->url),
    image ${E}
  }
`,(0,D.A)`
  *[
    _type == "solution" &&
    defined(slug.current)
  ] | order(coalesce(order,9999) asc, title asc) {
    "slug": slug.current
  }
`,(0,D.A)`
  *[
    _type == "solution" &&
    slug.current == $slug
  ][0]{
    _id,
    title,
    name,
    "slug": slug.current,
    category,
    shortDescription,
    description,
    summary,
    pageStyle,

    // Universal Direct Fallback URLs
    "imageUrl": coalesce(
      hero.image.asset->url,
      hero.imageUrl,
      heroImage.asset->url,
      image.asset->url,
      mainImage.asset->url,
      thumbnail.asset->url
    ),
    image ${E},
    heroImage ${E},
    mainImage ${E},

    "children": *[_type == "solution" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, category, shortDescription
    },

    hero{
      eyebrow,
      headline,
      highlight,
      description,
      "imageUrl": coalesce(
        image.asset->url,
        heroImage.asset->url,
        asset->url,
        imageUrl
      ),
      image ${E},
      heroImage ${E},

      primaryCta{label, href, page->${F}},
      secondaryCta{label, href, page->${F}}
    },

    stats[]{
      value,
      label,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E}
    },

    integrations,

    sections[]{
      ...,
      cta{..., page->${F}},
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E},

      items[]{
        ...,
        cta{..., page->${F}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      },

      cards[]{
        ...,
        cta{..., page->${F}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      },

      steps[]{
        ...,
        cta{..., page->${F}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      },

      _type == "splitContent" => {
        ...,
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${E}
      }
    },

    platformVariants[]{
      platform,
      "slug": slug.current,
      description,
      features,
      body
    },

    body[]{
      ...,
      _type == "image" => ${E}
    },

    "relatedServices": relatedServices[]->{
      _id,
      name,
      "slug": slug.current,
      pillar,
      shortDescription,
      "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url)
    },

    "industries": industries[]->{
      _id,
      title,
      "slug": slug.current,
      category,
      shortDescription
    },

    "relatedCaseStudies": relatedCaseStudies[]->{
      _id,
      title,
      "slug": slug.current,
      client,
      shortDescription
    },

    featured,
    order,

    seo{
      title,
      description,
      metaTitle,
      metaDescription,
      "ogImage": ogImage ${E},
      noIndex
    }
  }
`,(0,D.A)`
  *[
    _type == "industry" &&
    defined(slug.current) &&
    !defined(parent._ref)
  ] | order(coalesce(order, 9999) asc, title asc){
    _id,
    title,
    "slug": slug.current,
    "parentId": parent._ref,
    category,
    shortDescription,
    featured,
    "children": *[_type == "industry" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, shortDescription, featured,
      "children": *[_type == "industry" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
        _id, title, "slug": slug.current, shortDescription
      }
    },
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),
    "heroImage": coalesce(hero.image, image) ${E}
  }
`,(0,D.A)`
  *[
    _type == "industry" &&
    defined(slug.current)
  ] | order(coalesce(order, 9999) asc, title asc){
    _id,
    title,
    "slug": slug.current,
    "parentId": parent._ref,
    category,
    shortDescription,
    featured,
    "children": *[_type == "solution" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, shortDescription, featured,
      "children": *[_type == "solution" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
        _id, title, "slug": slug.current, shortDescription
      }
    },
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),
    "heroImage": coalesce(hero.image, image) ${E}
  }
`,(0,D.A)`
  *[
    _type == "industry" &&
    slug.current == $slug
  ][0]{
    _id,
    title,
    "slug": slug.current,
    category,
    shortDescription,
    featured,
    order,

    "children": *[_type == "industry" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, category, shortDescription
    },

    hero{
      eyebrow,
      headline,
      highlight,
      description,
      "imageUrl": coalesce(image.asset->url, heroImage.asset->url),
      image ${E},
      primaryCta{label, href, page->${F}},
      secondaryCta{label, href, page->${F}}
    },

    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),

    painPoints,
    characteristics[]{
      title,
      description,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E}
    },

    journey[]{
      number,
      title,
      description,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E}
    },

    ecosystem[]{
      name,
      category,
      description,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E}
    },

    capabilities[]{
      title,
      description,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${E}
    },

    stats[]{
      value,
      label
    },

    body[]{
      ...,
      _type == "image" => ${E}
    },

    relatedServices[]->{
      _id,
      name,
      "slug": slug.current,
      pillar,
      shortDescription,
      "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url)
    },

    relatedCaseStudies[]->{
      _id,
      title,
      "slug": slug.current,
      client,
      challenge,
      results[]{
        value,
        metric
      },
      "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url)
    },

    faqs[]{
      question,
      answer
    },

    seo{
      title,
      description,
      metaTitle,
      metaDescription,
      "ogImage": ogImage ${E},
      noIndex
    }
  }
`,(0,D.A)`
  *[
    _type == "caseStudy" &&
    defined(slug.current)
  ] | order(coalesce(order, 9999) asc, title asc) {
    "slug": slug.current
  }
`,(0,D.A)`
  *[
    _type == "caseStudy" &&
    defined(slug.current)
  ] | order(coalesce(order, 9999) asc, title asc) {
    _id,
    title,
    "slug": slug.current,
    "parentId": parent._ref
  }
`,(0,D.A)`
  *[
    _type == "caseStudy" &&
    defined(slug.current)
  ] | order(coalesce(order, 9999) asc, _createdAt desc){
    _id,
    title,
    "slug": slug.current,
    "parentId": parent._ref,
    client,
    shortDescription,
    challenge,
    "children": *[_type == "caseStudy" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, shortDescription, client
    },
    results[]{
      value,
      metric
    },
    featured,
    "industry": industry->{
      title,
      "slug": slug.current
    },
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url)
  }
`,(0,D.A)`
  *[
    _type == "caseStudy" &&
    slug.current == $slug
  ][0]{
    _id,
    title,
    "slug": slug.current,
    client,
    shortDescription,

    // Legacy top-level hero image — projected so the renderer's fallback
    // (for case studies whose image lives here instead of hero.image)
    // actually resolves to a real asset URL instead of always being null.
    heroImage ${E},
    "imageUrl": coalesce(hero.image.asset->url, heroImage.asset->url),

    "children": *[_type == "caseStudy" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, client, shortDescription
    },

    hero{
      eyebrow,
      headline,
      highlight,
      description,
      "imageUrl": coalesce(image.asset->url, heroImage.asset->url),
      image ${E},
      primaryCta{label, href, page->${F}},
      secondaryCta{label, href, page->${F}}
    },

    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),

    "industry": industry->{
      _id,
      title,
      "slug": slug.current
    },

    "servicesUsed": servicesUsed[]->{
      _id,
      name,
      "slug": slug.current,
      pillar,
      shortDescription
    },

    challenge,
    approach,
    solution,
    execution,
    stack,

    results[]{
      value,
      metric
    },

    quote,
    quoteAuthor,
    quoteRole,

    body[]{
      ...,
      _type == "image" => ${E}
    },

    "gallery": gallery[] ${E},

    "relatedCaseStudies": relatedCaseStudies[]->{
      _id,
      title,
      "slug": slug.current,
      client,
      shortDescription,
      results[]{
        value,
        metric
      },
      "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),
      "industry": industry->{
        title,
        "slug": slug.current
      }
    },

    seo{
      title,
      description,
      metaTitle,
      metaDescription,
      "ogImage": ogImage ${E},
      noIndex
    }
  }
`,(0,D.A)`
  *[_type == "siteSettings"][0]{
    "headerLogo": coalesce(headerLogoDark, headerLogoLight) ${E},
    "headerLogoUrl": coalesce(headerLogoDark.asset->url, headerLogoLight.asset->url),
    headerLogoDark ${E},
    headerLogoLight ${E},
    headerLogoAlt,

    navLinks[]{
      label,
      href,
      type
    },

    footerLogo ${E},
    "footerLogoUrl": footerLogo.asset->url,
    footerDescription,
    contactEmail,
    contactPhone,

    footerColumns[]{
      title,
      links[]{
        label,
        href
      }
    },

    footerCta{
      label,
      href
    },

    socialLinks[]{
      platform,
      url
    },

    defaultSeo{
      ...,
      "ogImage": ogImage ${E}
    }
  }
`,(0,D.A)`
  *[_type == "aboutPage"][0]{
    title,
    slug,

    hero{
      eyebrow,
      headline,
      highlight,
      description,
      "imageUrl": image.asset->url,
      image ${E},

      primaryCta{
        label,
        href,
        page->${F}
      }
    },

    sections[]{
      ...,

      cta{
        ...,
        page->${F}
      },

      "imageUrl": coalesce(
        image.asset->url,
        asset->url
      ),

      image ${E},

      items[]{
        ...,
        cta{
          ...,
          page->${F}
        },
        "imageUrl": coalesce(
          image.asset->url,
          asset->url
        ),
        image ${E}
      },

      cards[]{
        ...,
        cta{
          ...,
          page->${F}
        },
        "imageUrl": coalesce(
          image.asset->url,
          asset->url
        ),
        image ${E}
      },

      steps[]{
        ...,
        cta{
          ...,
          page->${F}
        },
        "imageUrl": coalesce(
          image.asset->url,
          asset->url
        ),
        image ${E}
      },

      members[]{
        ...,
        "imageUrl": coalesce(
          image.asset->url,
          photo.asset->url
        ),
        image ${E}
      },

      partners[]{
        ...,
        "imageUrl": coalesce(
          image.asset->url,
          logo.asset->url
        ),
        image ${E}
      },

      testimonials[]->{
        _id,
        quote,
        name,
        title,
        company,
        "imageUrl": coalesce(
          image.asset->url,
          asset->url
        ),
        image ${E}
      }
    },

    "partnerGrid": {
      "eyebrow": "Our Partners",
      "heading": "Technology that powers our work",
      "description": "We work with leading commerce, marketing, ERP, customer experience, and digital platforms.",

      "partners": *[_type == "homepage"][0].partnersMarquee.partners[]{
        name,
        url,
        "imageUrl": coalesce(
          logo.asset->url,
          image.asset->url
        )
      }
    },

    vendorsSection{
      eyebrow,
      title,
      subtitle,
      items[]->{
        _id, name, category, url,
        "imageUrl": coalesce(logo.asset->url, logo.assetUrl),
        logo ${E}
      }
    },

    seo{
      title,
      description,
      metaTitle,
      metaDescription,
      "ogImage": ogImage ${E},
      noIndex
    }
  }
`;var G=c(93313);let H=["build","automate","scale","grow","support"];function I(a=""){return String(a).trim().toLowerCase().replace(/[_-]+/g,"")}function J({settings:a=null}){let[b,c]=(0,g.useState)(a),[e,p]=(0,g.useState)(!1),[q,r]=(0,g.useState)(null),[s,t]=(0,g.useState)(!1),[u,x]=(0,g.useState)(!1),y=(0,G.Y)(a=>a.services),A=(0,G.Y)(a=>a.industries),C=(0,G.Y)(a=>a.solutions),D=(0,G.Y)(a=>a.caseStudies),E=(0,G.Y)(a=>a.servicesLoaded),F=(0,G.Y)(a=>a.industriesLoaded),J=(0,G.Y)(a=>a.solutionsLoaded);(0,G.Y)(a=>a.caseStudiesLoaded),(0,G.Y)(a=>a.setServices),(0,G.Y)(a=>a.setIndustries),(0,G.Y)(a=>a.setSolutions),(0,G.Y)(a=>a.setCaseStudies);let{scrollY:M}=(0,h.L)();(0,i.L)(M,"change",a=>{p(a>40)});let N=a=>{r(a)},O=()=>{r(null)},P=()=>{r(null),x(!1),t(!1)},Q=b?.headerLogo?.assetUrl,R=b?.headerLogoAlt||"Tendrils.io",S=H.reduce((a,b)=>(a[b]=y.filter(a=>!a?.parentId&&I(a?.pillar)===I(b)),a),{});return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(j.N,{children:q&&(0,d.jsx)(k.P.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:.2},className:"fixed inset-0 z-40 bg-black/20 backdrop-blur-sm pointer-events-none"})}),(0,d.jsx)(k.P.header,{initial:{y:-80,opacity:0},animate:{y:0,opacity:1},transition:{duration:.8,ease:"easeOut"},className:"fixed top-2 md:top-4 inset-x-0 z-[100] flex justify-center px-2 md:px-4",children:(0,d.jsxs)("div",{className:`
            relative flex items-center justify-between
            rounded-full
            border border-[#D4AF37]/20
            px-4 md:px-8
            transition-all duration-500
            backdrop-blur-xl
            w-full max-w-[1490px]

            ${e?"py-2 md:py-3 bg-[#F7F2E8]/95 shadow-[0_8px_30px_rgba(201,162,39,0.25)]":"py-2.5 md:py-4 bg-[#F7F2E8]/80"}
          `,children:[(0,d.jsx)(f(),{href:"/",onClick:P,className:"flex shrink-0 items-center outline-none",children:Q?(0,d.jsx)("img",{src:Q,alt:R,className:" h-9 w-auto max-w-[115px] object-contain md:h-14 md:max-w-[150px] "}):(0,d.jsx)("span",{className:"font-display text-xl md:text-2xl tracking-wide text-black font-semibold",children:"Tendrils.io"})}),(0,d.jsxs)("nav",{className:"hidden items-center gap-8 lg:flex h-full",children:[(0,d.jsx)("div",{className:"relative flex h-full items-center",onMouseEnter:()=>N("services"),children:(0,d.jsxs)(f(),{href:"/services",onClick:P,className:" group flex items-center gap-1.5 text-[15px] font-semibold text-black tracking-wide hover:text-[#9A7625] transition-colors ",children:["Services",(0,d.jsx)(l.A,{onClick:a=>{a.preventDefault(),a.stopPropagation(),r("services"===q?null:"services")},className:`
                    h-4 w-4
                    transition-transform duration-300
                    ${"services"===q?"rotate-180 text-[#9A7625]":""}
                  `,strokeWidth:1.8})]})}),(0,d.jsx)("div",{className:"relative flex h-full items-center",onMouseEnter:()=>N("industries"),children:(0,d.jsxs)(f(),{href:"/industries",onClick:P,className:" group flex items-center gap-1.5 text-[15px] font-semibold text-black tracking-wide hover:text-[#9A7625] transition-colors ",children:["Industries",(0,d.jsx)(l.A,{onClick:a=>{a.preventDefault(),a.stopPropagation(),r("industries"===q?null:"industries")},className:`
                    h-4 w-4
                    transition-transform duration-300
                    ${"industries"===q?"rotate-180 text-[#9A7625]":""}
                  `,strokeWidth:1.8})]})}),(0,d.jsx)("div",{className:"relative flex h-full items-center",onMouseEnter:()=>N("solutions"),children:(0,d.jsxs)(f(),{href:"/solutions",onClick:P,className:" group flex items-center gap-1.5 text-[15px] font-semibold text-black tracking-wide hover:text-[#9A7625] transition-colors ",children:["Solutions",(0,d.jsx)(l.A,{onClick:a=>{a.preventDefault(),a.stopPropagation(),r("solutions"===q?null:"solutions")},className:`
                    h-4 w-4
                    transition-transform duration-300
                    ${"solutions"===q?"rotate-180 text-[#9A7625]":""}
                  `,strokeWidth:1.8})]})}),(0,d.jsx)("div",{className:"relative flex h-full items-center",onMouseEnter:()=>N("caseStudies"),children:(0,d.jsxs)(f(),{href:"/case-studies",onClick:P,className:" group flex items-center gap-1.5 text-[15px] font-semibold text-black tracking-wide hover:text-[#9A7625] transition-colors ",children:["Case Studies",D.length>0&&(0,d.jsx)(l.A,{onClick:a=>{a.preventDefault(),a.stopPropagation(),r("caseStudies"===q?null:"caseStudies")},className:`
                      h-4 w-4
                      transition-transform duration-300
                      ${"caseStudies"===q?"rotate-180 text-[#9A7625]":""}
                    `,strokeWidth:1.8})]})}),(0,d.jsx)(f(),{href:"/about",onClick:P,className:" text-[15px] font-semibold text-black tracking-wide hover:text-[#9A7625] transition-colors ",children:"About Us"})]}),(0,d.jsxs)("div",{className:"flex items-center gap-2 md:gap-3 shrink-0",children:[(0,d.jsx)("button",{type:"button",onClick:()=>{r(null),x(!1),t(a=>!a)},"aria-label":s?"Close search":"Search",className:" flex h-9 w-9 md:h-11 md:w-11 items-center justify-center rounded-full border border-black/10 text-black transition hover:border-black hover:bg-black hover:text-white ",children:s?(0,d.jsx)(m.A,{className:"h-4 w-4"}):(0,d.jsx)(n.A,{className:"h-4 w-4"})}),(0,d.jsx)(f(),{href:"/contact",onClick:P,className:" hidden rounded-full bg-[#C5A05A] px-7 py-3 text-sm font-semibold text-black transition-all duration-300 hover:bg-black hover:text-[#F7F2E8] hover:shadow-lg xl:inline-block ",children:"Book a Consultation"}),(0,d.jsx)("button",{type:"button",className:" lg:hidden flex h-9 w-9 md:h-10 md:w-10 items-center justify-center rounded-full border border-black/10 text-black ",onClick:()=>x(!u),"aria-label":u?"Close menu":"Open menu",children:u?(0,d.jsx)(m.A,{className:"h-5 w-5"}):(0,d.jsx)(o.A,{className:"h-5 w-5"})})]})]})}),(0,d.jsx)(j.N,{children:"services"===q&&(0,d.jsx)(k.P.div,{initial:{opacity:0,y:8},animate:{opacity:1,y:0},exit:{opacity:0,y:8},transition:{duration:.18},onMouseEnter:()=>N("services"),onMouseLeave:O,style:{top:e?96:122,left:"calc(50% - min(657.5px, calc(50vw - 24px)))"},className:" fixed z-[110] w-[calc(100vw-48px)] max-w-[1315px] ",children:(0,d.jsx)(v,{services:y,groupedServices:S,loaded:E,onNavigate:O})})}),(0,d.jsx)(j.N,{children:"industries"===q&&(0,d.jsx)(k.P.div,{initial:{opacity:0,y:8},animate:{opacity:1,y:0},exit:{opacity:0,y:8},transition:{duration:.18},onMouseEnter:()=>N("industries"),onMouseLeave:O,style:{top:e?96:122,left:"calc(50% - min(657.5px, calc(50vw - 24px)))"},className:" fixed z-[110] w-[calc(100vw-48px)] max-w-[1315px] ",children:(0,d.jsx)(w,{industries:A,loaded:F,onClose:O})})}),(0,d.jsx)(j.N,{children:"solutions"===q&&(0,d.jsx)(k.P.div,{initial:{opacity:0,y:8},animate:{opacity:1,y:0},exit:{opacity:0,y:8},transition:{duration:.18},onMouseEnter:()=>N("solutions"),onMouseLeave:O,style:{top:e?96:122,left:"calc(50% - min(657.5px, calc(50vw - 24px)))"},className:" fixed z-[110] w-[calc(100vw-48px)] max-w-[1315px] ",children:(0,d.jsx)(z,{solutions:C,loaded:J,onClose:O})})}),(0,d.jsx)(j.N,{children:"caseStudies"===q&&D.length>0&&(0,d.jsx)(k.P.div,{initial:{opacity:0,y:8},animate:{opacity:1,y:0},exit:{opacity:0,y:8},transition:{duration:.18},onMouseEnter:()=>N("caseStudies"),onMouseLeave:O,style:{top:e?96:122,left:"calc(50% - min(525px, calc(50vw - 24px)))"},className:" fixed z-[110] w-[calc(100vw-48px)] max-w-[1050px] ",children:(0,d.jsx)(K,{caseStudies:D,onClose:O})})}),(0,d.jsx)(j.N,{children:u&&(0,d.jsx)(k.P.div,{initial:{opacity:0,y:-10},animate:{opacity:1,y:0},exit:{opacity:0,y:-10},className:" fixed inset-x-2 top-[58px] z-[95] overflow-y-auto rounded-[28px] border border-black/10 bg-[#F7F2E8] p-6 shadow-[0_25px_80px_rgba(0,0,0,0.18)] lg:hidden ",children:(0,d.jsxs)("div",{className:"space-y-2",children:[(0,d.jsx)(L,{label:"Services",href:"/services",onClick:P}),(0,d.jsx)(L,{label:"Industries",href:"/industries",onClick:P}),(0,d.jsx)(L,{label:"Solutions",href:"/solutions",onClick:P}),(0,d.jsx)(L,{label:"Case Studies",href:"/case-studies",onClick:P}),(0,d.jsx)(L,{label:"About Us",href:"/about",onClick:P}),(0,d.jsx)(f(),{href:"/contact",onClick:P,className:" mt-4 flex h-12 items-center justify-center rounded-full bg-[#C5A05A] text-sm font-semibold text-black ",children:"Book a Consultation"})]})})}),(0,d.jsx)(B,{open:s,onClose:()=>t(!1)})]})}function K({caseStudies:a=[],onClose:b}){return(0,d.jsx)("div",{className:" w-full overflow-hidden rounded-[28px] border border-[#C5A05A]/20 bg-[#F7F2E8]/95 backdrop-blur-2xl shadow-[0_24px_70px_rgba(0,0,0,0.18)] ",children:(0,d.jsxs)("div",{className:" grid grid-cols-[280px_minmax(0,1fr)] gap-6 p-6 ",children:[(0,d.jsxs)("div",{className:" flex min-h-[320px] flex-col rounded-[22px] bg-black p-7 text-[#F7F2E8] justify-between ",children:[(0,d.jsxs)("div",{children:[(0,d.jsx)("p",{className:" text-[10px] font-bold uppercase tracking-[0.28em] text-[#C5A05A] ",children:"Tendrils Case Studies"}),(0,d.jsxs)("h3",{className:" mt-5 font-display text-[26px] leading-[1.05] tracking-tight ",children:["Proof that",(0,d.jsx)("br",{}),"the system works."]}),(0,d.jsx)("p",{className:" mt-5 text-[12px] leading-5 text-white/55 ",children:"Explore the commerce systems, transformations, and outcomes we have engineered."})]}),(0,d.jsxs)(f(),{href:"/case-studies",onClick:b,className:" inline-flex items-center gap-2 text-xs font-semibold text-[#C5A05A] hover:text-white ",children:["Explore all case studies",(0,d.jsx)(p.A,{className:"h-3.5 w-3.5"})]})]}),(0,d.jsx)("div",{className:" grid min-h-[320px] grid-cols-1 gap-3 p-2 sm:grid-cols-2 ",children:a.map(a=>(0,d.jsx)("div",{className:" rounded-2xl border border-black/5 bg-white/60 p-4 hover:border-[#C5A05A]/30 hover:bg-white ",children:(0,d.jsxs)(f(),{href:`/case-studies/${a.slug}`,onClick:b,className:" group flex items-center justify-between ",children:[(0,d.jsxs)("div",{className:"min-w-0",children:[(0,d.jsx)("p",{className:" truncate text-[13px] font-semibold text-black/90 group-hover:text-black ",children:a.title}),a.client&&(0,d.jsx)("p",{className:" mt-1 text-[10px] uppercase tracking-[0.14em] text-black/40 ",children:a.client})]}),(0,d.jsx)(p.A,{className:" h-4 w-4 text-[#9A7625] opacity-0 group-hover:opacity-100 "})]})},a._id))})]})})}function L({label:a,href:b,onClick:c}){return(0,d.jsxs)(f(),{href:b,onClick:c,className:" group flex items-center justify-between rounded-2xl border border-transparent px-4 py-4 text-[15px] font-semibold text-black transition hover:border-[#C5A05A]/30 hover:bg-white ",children:[(0,d.jsx)("span",{children:a}),(0,d.jsx)(p.A,{className:" h-4 w-4 text-[#9A7625] opacity-60 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:opacity-100 "})]})}},68509:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>k});var d=c(75338),e=c(93662),f=c(95481),g=c(49328),h=c(42247),i=c(72425);async function j({children:a}){let b=null;try{b=await e.S.fetch(f.LX)}catch(a){console.warn("Site settings unavailable:",a.message)}return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(g.default,{settings:b}),(0,d.jsx)(h.default,{settings:b}),(0,d.jsx)("div",{className:"min-h-screen",children:a}),(0,d.jsx)(i.default,{settings:b})]})}function k({children:a}){return(0,d.jsx)(j,{children:a})}},72425:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(97954).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\tendril_site_shree_updated_02\\\\src\\\\components\\\\layout\\\\Footer.jsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\tendril_site_shree_updated_02\\src\\components\\layout\\Footer.jsx","default")},93313:(a,b,c)=>{"use strict";c.d(b,{Y:()=>d});let d=(0,c(18610).vt)(a=>({services:[],industries:[],solutions:[],caseStudies:[],servicesLoaded:!1,industriesLoaded:!1,solutionsLoaded:!1,caseStudiesLoaded:!1,setServices:b=>a({services:Array.isArray(b)?b:[],servicesLoaded:!0}),setIndustries:b=>a({industries:Array.isArray(b)?b:[],industriesLoaded:!0}),setSolutions:b=>a({solutions:Array.isArray(b)?b:[],solutionsLoaded:!0}),setCaseStudies:b=>a({caseStudies:Array.isArray(b)?b:[],caseStudiesLoaded:!0}),hydrate:({services:b=[],industries:c=[],solutions:d=[],caseStudies:e=[]}={})=>a({services:Array.isArray(b)?b:[],industries:Array.isArray(c)?c:[],solutions:Array.isArray(d)?d:[],caseStudies:Array.isArray(e)?e:[],servicesLoaded:!0,industriesLoaded:!0,solutionsLoaded:!0,caseStudiesLoaded:!0})}))},95651:()=>{},97634:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>j,metadata:()=>i});var d=c(75338),e=c(87807),f=c.n(e),g=c(57975),h=c.n(g);c(61135);let i={metadataBase:new URL("https://www.tendrils.com"),title:{default:"Tendrils — Shopify Growth Partner",template:"%s | Tendrils"},description:"Build, integrate, automate, and scale Shopify businesses end-to-end."};function j({children:a}){return(0,d.jsx)("html",{lang:"en",className:`${f().variable} ${h().variable}`,children:(0,d.jsx)("body",{className:"font-body bg-ivory text-ink antialiased overflow-x-hidden",children:a})})}}};