"use strict";exports.id=6779,exports.ids=[6779],exports.modules={83073:(a,b,c)=>{c.r(b),c.d(b,{"7f7509861306f476728bb81090cf6541f3d1e5e6e9":()=>d.q});var d=c(52227)},93662:(a,b,c)=>{c.d(b,{S:()=>d});let d=(0,c(58715).UU)({projectId:"zggcyoyq",dataset:"production",apiVersion:"2024-08-01",useCdn:!1,perspective:"published"})},95481:(a,b,c)=>{c.d(b,{EQ:()=>i,GM:()=>n,JT:()=>r,Jb:()=>g,LX:()=>u,O4:()=>t,PE:()=>o,TV:()=>j,Ts:()=>q,Vf:()=>l,X0:()=>v,Xl:()=>k,cc:()=>s,hS:()=>m,nt:()=>p,zQ:()=>h});var d=c(76575);let e=`{
  ...,
  "assetUrl": coalesce(asset->url, url)
}`,f=`{
  _id,
  _type,
  "slug": slug.current,
  "parent": parent->{
    "slug": slug.current,
    "parent": parent->{
      "slug": slug.current,
      "parent": parent->{
        "slug": slug.current
      }
    }
  }
}`;(0,d.A)`
  *[_type == "vendor"] | order(order asc, name asc){
    _id,
    name,
    category,
    url,
    "imageUrl": coalesce(logo.asset->url, logo.assetUrl),
    logo ${e}
  }
`;let g=(0,d.A)`
  *[_type == "homepage"][0]{
    title,

    hero{
      eyebrow,
      headline,
      highlight,
      description,

      "imageUrl": coalesce(image.asset->url, heroImage.asset->url, image.assetUrl),
      image ${e},
      heroImage ${e},

      primaryCta{label, href, page->${f}},
      secondaryCta{label, href, page->${f}}
    },

    stats[]{
      value,
      label,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e}
    },

    partnersMarquee{
      label,
      partners[]{
        name,
        url,
        "imageUrl": coalesce(logo.asset->url, image.asset->url),
        logo ${e}
      }
    },

    marketingGrid[]{
      key,
      title,
      description,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e}
    },

    vendorsSection{
      eyebrow,
      title,
      subtitle,
      items[]->{
        _id, name, category, url,
        "imageUrl": coalesce(logo.asset->url, logo.assetUrl),
        logo ${e}
      }
    },

    "testimonials": coalesce(
      testimonials[]->{
        _id,
        quote,
        name,
        title,
        company,
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      },
      []
    ),

    expertise{
      title,
      subtitle,

      items[]{
        heading,
        description,
        "imageUrl": coalesce(image.asset->url, heroImage.asset->url),
        image ${e},
        cta{label, href}
      }
    },

    industriesSection{
      eyebrow,
      title,
      subtitle,
      cta{label, href},
      items[]->{
        _id,
        title,
        "slug": slug.current,
        category,
        shortDescription,
        "imageUrl": coalesce(homeImage.asset->url, hero.image.asset->url, image.asset->url),
        homeImage ${e},
        image ${e}
      }
    },

    solutionsSection{
      eyebrow,
      title,
      subtitle,
      cta{label, href},
      items[]->{
        _id,
        title,
        "slug": slug.current,
        category,
        shortDescription,
        summary,
        "imageUrl": coalesce(homeImage.asset->url, hero.image.asset->url, image.asset->url),
        homeImage ${e},
        image ${e}
      }
    },

    whyChooseUs{
      title,
      subtitle,
      features[]{
        title,
        description,
        "imageUrl": coalesce(image.asset->url, heroImage.asset->url),
        image ${e},
        cta{label, href}
      }
    },

    sections[]{
      ...,
      cta{..., page->${f}},
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e},

      items[]{
        ...,
        cta{..., page->${f}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      },

      cards[]{
        ...,
        cta{..., page->${f}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      },

      steps[]{
        ...,
        cta{..., page->${f}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      },

      members[]{
        ...,
        "imageUrl": coalesce(image.asset->url, photo.asset->url),
        image ${e}
      },

      partners[]{
        ...,
        "imageUrl": coalesce(image.asset->url, logo.asset->url),
        image ${e}
      },

      testimonials[]->{
        _id,
        quote,
        name,
        title,
        company,
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      }
    },

    finalCta{
      eyebrow,
      title,
      description,
      cta{label, href, page->${f}}
    }
  }
`,h=(0,d.A)`
  *[_type == "service"] | order(coalesce(order, 9999) asc, name asc) {
    _id,
    name,
    "slug": slug.current,
    pillar,
    shortDescription,
    description,
    featured,
    order,

    parentService->{
      _id,
      name,
      "slug": slug.current
    },

    parentId,
    "imageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),
    "heroImage": coalesce(hero.image, heroImage, image) ${e},
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url)
  }
`,i=(0,d.A)`
  *[
    _type == "service" &&
    slug.current == $slug
  ][0]{
    _id,
    name,
    "slug": slug.current,
    pillar,
    shortDescription,
    description,
    order,
    featured,
    pageStyle,

    // Root level image fallbacks
    "imageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),
    image ${e},

    hero{
      eyebrow,
      headline,
      highlight,
      description,
      "imageUrl": coalesce(image.asset->url, heroImage.asset->url, asset->url),
      image ${e},
      heroImage ${e},

      primaryCta{
        label,
        href,
        page->{
          _type,
          _id,
          "slug": slug.current
        }
      },

      secondaryCta{
        label,
        href,
        page->{
          _type,
          _id,
          "slug": slug.current
        }
      }
    },

    stats[]{
      ...,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e}
    },

    sections[]{
      ...,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e},

      items[]{
        ...,
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      },

      cards[]{
        ...,
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      }
    },

    "parent": parent->{
      _id,
      name,
      "slug": slug.current
    },

    "children": *[
      _type == "service" &&
      parent._ref == ^._id &&
      defined(slug.current)
    ] | order(coalesce(order, 9999) asc, name asc) {
      _id,
      name,
      "slug": slug.current,
      shortDescription
    },

    "relatedServices": relatedServices[]->{
      _id,
      name,
      "slug": slug.current,
      pillar,
      shortDescription
    },

    "industries": industries[]->{
      _id,
      title,
      "slug": slug.current
    },

    seo{
      title,
      description,
      metaTitle,
      metaDescription,
      "ogImage": ogImage ${e},
      noIndex
    }
  }
`,j=(0,d.A)`
  *[
    _type == "service" &&
    defined(slug.current)
  ] | order(coalesce(order, 9999) asc, name asc) {
    _id,
    name,
    "slug": slug.current,
    "parentId": parent._ref,
    order
  }
`,k=(0,d.A)`
  *[
    _type == "service" &&
    defined(slug.current) &&
    !defined(parent._ref)
  ] | order(coalesce(order, 9999) asc, name asc) {
    _id,
    name,
    "slug": slug.current,
    pillar,
    shortDescription,
    order,

    "children": *[
      _type == "service" &&
      parent._ref == ^._id &&
      defined(slug.current)
    ] | order(coalesce(order, 9999) asc, name asc) {
      _id,
      name,
      "slug": slug.current,
      pillar,
      shortDescription,
      order,

      "children": *[
        _type == "service" &&
        parent._ref == ^._id &&
        defined(slug.current)
      ] | order(coalesce(order, 9999) asc, name asc) {
        _id,
        name,
        "slug": slug.current,
        pillar,
        shortDescription,
        order
      }
    }
  }
`,l=(0,d.A)`
  *[
    _type == "solution" &&
    defined(slug.current) &&
    !defined(parent._ref)
  ] | order(coalesce(order, 9999) asc, title asc) {
    _id,
    title,
    "slug": slug.current,
    "parentId": parent._ref,
    category,
    shortDescription,
    featured,
    "children": *[_type == "solution" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, shortDescription, featured,
      "children": *[_type == "solution" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
        _id, title, "slug": slug.current, shortDescription
      }
    },
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url)
  }
`,m=(0,d.A)`
  *[
    _type == "solution" &&
    defined(slug.current)
  ] | order(featured desc, coalesce(order, 9999) asc, title asc) {
    _id,
    title,
    "slug": slug.current,
    category,
    shortDescription,
    summary,
    featured,
    pageStyle,
    integrations,
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url, mainImage.asset->url),
    image ${e}
  }
`;(0,d.A)`
  *[
    _type == "solution" &&
    defined(slug.current)
  ] | order(coalesce(order,9999) asc, title asc) {
    "slug": slug.current
  }
`;let n=(0,d.A)`
  *[
    _type == "solution" &&
    slug.current == $slug
  ][0]{
    _id,
    title,
    name,
    "slug": slug.current,
    category,
    shortDescription,
    description,
    summary,
    pageStyle,

    // Universal Direct Fallback URLs
    "imageUrl": coalesce(
      hero.image.asset->url,
      hero.imageUrl,
      heroImage.asset->url,
      image.asset->url,
      mainImage.asset->url,
      thumbnail.asset->url
    ),
    image ${e},
    heroImage ${e},
    mainImage ${e},

    "children": *[_type == "solution" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, category, shortDescription
    },

    hero{
      eyebrow,
      headline,
      highlight,
      description,
      "imageUrl": coalesce(
        image.asset->url,
        heroImage.asset->url,
        asset->url,
        imageUrl
      ),
      image ${e},
      heroImage ${e},

      primaryCta{label, href, page->${f}},
      secondaryCta{label, href, page->${f}}
    },

    stats[]{
      value,
      label,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e}
    },

    integrations,

    sections[]{
      ...,
      cta{..., page->${f}},
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e},

      items[]{
        ...,
        cta{..., page->${f}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      },

      cards[]{
        ...,
        cta{..., page->${f}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      },

      steps[]{
        ...,
        cta{..., page->${f}},
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      },

      _type == "splitContent" => {
        ...,
        "imageUrl": coalesce(image.asset->url, asset->url),
        image ${e}
      }
    },

    platformVariants[]{
      platform,
      "slug": slug.current,
      description,
      features,
      body
    },

    body[]{
      ...,
      _type == "image" => ${e}
    },

    "relatedServices": relatedServices[]->{
      _id,
      name,
      "slug": slug.current,
      pillar,
      shortDescription,
      "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url)
    },

    "industries": industries[]->{
      _id,
      title,
      "slug": slug.current,
      category,
      shortDescription
    },

    "relatedCaseStudies": relatedCaseStudies[]->{
      _id,
      title,
      "slug": slug.current,
      client,
      shortDescription
    },

    featured,
    order,

    seo{
      title,
      description,
      metaTitle,
      metaDescription,
      "ogImage": ogImage ${e},
      noIndex
    }
  }
`,o=(0,d.A)`
  *[
    _type == "industry" &&
    defined(slug.current) &&
    !defined(parent._ref)
  ] | order(coalesce(order, 9999) asc, title asc){
    _id,
    title,
    "slug": slug.current,
    "parentId": parent._ref,
    category,
    shortDescription,
    featured,
    "children": *[_type == "industry" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, shortDescription, featured,
      "children": *[_type == "industry" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
        _id, title, "slug": slug.current, shortDescription
      }
    },
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),
    "heroImage": coalesce(hero.image, image) ${e}
  }
`,p=(0,d.A)`
  *[
    _type == "industry" &&
    defined(slug.current)
  ] | order(coalesce(order, 9999) asc, title asc){
    _id,
    title,
    "slug": slug.current,
    "parentId": parent._ref,
    category,
    shortDescription,
    featured,
    "children": *[_type == "solution" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, shortDescription, featured,
      "children": *[_type == "solution" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
        _id, title, "slug": slug.current, shortDescription
      }
    },
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),
    "heroImage": coalesce(hero.image, image) ${e}
  }
`,q=(0,d.A)`
  *[
    _type == "industry" &&
    slug.current == $slug
  ][0]{
    _id,
    title,
    "slug": slug.current,
    category,
    shortDescription,
    featured,
    order,

    "children": *[_type == "industry" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, category, shortDescription
    },

    hero{
      eyebrow,
      headline,
      highlight,
      description,
      "imageUrl": coalesce(image.asset->url, heroImage.asset->url),
      image ${e},
      primaryCta{label, href, page->${f}},
      secondaryCta{label, href, page->${f}}
    },

    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),

    painPoints,
    characteristics[]{
      title,
      description,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e}
    },

    journey[]{
      number,
      title,
      description,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e}
    },

    ecosystem[]{
      name,
      category,
      description,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e}
    },

    capabilities[]{
      title,
      description,
      "imageUrl": coalesce(image.asset->url, asset->url),
      image ${e}
    },

    stats[]{
      value,
      label
    },

    body[]{
      ...,
      _type == "image" => ${e}
    },

    relatedServices[]->{
      _id,
      name,
      "slug": slug.current,
      pillar,
      shortDescription,
      "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url)
    },

    relatedCaseStudies[]->{
      _id,
      title,
      "slug": slug.current,
      client,
      challenge,
      results[]{
        value,
        metric
      },
      "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url)
    },

    faqs[]{
      question,
      answer
    },

    seo{
      title,
      description,
      metaTitle,
      metaDescription,
      "ogImage": ogImage ${e},
      noIndex
    }
  }
`;(0,d.A)`
  *[
    _type == "caseStudy" &&
    defined(slug.current)
  ] | order(coalesce(order, 9999) asc, title asc) {
    "slug": slug.current
  }
`;let r=(0,d.A)`
  *[
    _type == "caseStudy" &&
    defined(slug.current)
  ] | order(coalesce(order, 9999) asc, title asc) {
    _id,
    title,
    "slug": slug.current,
    "parentId": parent._ref
  }
`,s=(0,d.A)`
  *[
    _type == "caseStudy" &&
    defined(slug.current)
  ] | order(coalesce(order, 9999) asc, _createdAt desc){
    _id,
    title,
    "slug": slug.current,
    "parentId": parent._ref,
    client,
    shortDescription,
    challenge,
    "children": *[_type == "caseStudy" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, shortDescription, client
    },
    results[]{
      value,
      metric
    },
    featured,
    "industry": industry->{
      title,
      "slug": slug.current
    },
    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url)
  }
`,t=(0,d.A)`
  *[
    _type == "caseStudy" &&
    slug.current == $slug
  ][0]{
    _id,
    title,
    "slug": slug.current,
    client,
    shortDescription,

    // Legacy top-level hero image — projected so the renderer's fallback
    // (for case studies whose image lives here instead of hero.image)
    // actually resolves to a real asset URL instead of always being null.
    heroImage ${e},
    "imageUrl": coalesce(hero.image.asset->url, heroImage.asset->url),

    "children": *[_type == "caseStudy" && parent._ref == ^._id && defined(slug.current)] | order(coalesce(order,9999) asc, title asc){
      _id, title, "slug": slug.current, client, shortDescription
    },

    hero{
      eyebrow,
      headline,
      highlight,
      description,
      "imageUrl": coalesce(image.asset->url, heroImage.asset->url),
      image ${e},
      primaryCta{label, href, page->${f}},
      secondaryCta{label, href, page->${f}}
    },

    "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),

    "industry": industry->{
      _id,
      title,
      "slug": slug.current
    },

    "servicesUsed": servicesUsed[]->{
      _id,
      name,
      "slug": slug.current,
      pillar,
      shortDescription
    },

    challenge,
    approach,
    solution,
    execution,
    stack,

    results[]{
      value,
      metric
    },

    quote,
    quoteAuthor,
    quoteRole,

    body[]{
      ...,
      _type == "image" => ${e}
    },

    "gallery": gallery[] ${e},

    "relatedCaseStudies": relatedCaseStudies[]->{
      _id,
      title,
      "slug": slug.current,
      client,
      shortDescription,
      results[]{
        value,
        metric
      },
      "heroImageUrl": coalesce(hero.image.asset->url, heroImage.asset->url, image.asset->url),
      "industry": industry->{
        title,
        "slug": slug.current
      }
    },

    seo{
      title,
      description,
      metaTitle,
      metaDescription,
      "ogImage": ogImage ${e},
      noIndex
    }
  }
`,u=(0,d.A)`
  *[_type == "siteSettings"][0]{
    "headerLogo": coalesce(headerLogoDark, headerLogoLight) ${e},
    "headerLogoUrl": coalesce(headerLogoDark.asset->url, headerLogoLight.asset->url),
    headerLogoDark ${e},
    headerLogoLight ${e},
    headerLogoAlt,

    navLinks[]{
      label,
      href,
      type
    },

    footerLogo ${e},
    "footerLogoUrl": footerLogo.asset->url,
    footerDescription,
    contactEmail,
    contactPhone,

    footerColumns[]{
      title,
      links[]{
        label,
        href
      }
    },

    footerCta{
      label,
      href
    },

    socialLinks[]{
      platform,
      url
    },

    defaultSeo{
      ...,
      "ogImage": ogImage ${e}
    }
  }
`,v=(0,d.A)`
  *[_type == "aboutPage"][0]{
    title,
    slug,

    hero{
      eyebrow,
      headline,
      highlight,
      description,
      "imageUrl": image.asset->url,
      image ${e},

      primaryCta{
        label,
        href,
        page->${f}
      }
    },

    sections[]{
      ...,

      cta{
        ...,
        page->${f}
      },

      "imageUrl": coalesce(
        image.asset->url,
        asset->url
      ),

      image ${e},

      items[]{
        ...,
        cta{
          ...,
          page->${f}
        },
        "imageUrl": coalesce(
          image.asset->url,
          asset->url
        ),
        image ${e}
      },

      cards[]{
        ...,
        cta{
          ...,
          page->${f}
        },
        "imageUrl": coalesce(
          image.asset->url,
          asset->url
        ),
        image ${e}
      },

      steps[]{
        ...,
        cta{
          ...,
          page->${f}
        },
        "imageUrl": coalesce(
          image.asset->url,
          asset->url
        ),
        image ${e}
      },

      members[]{
        ...,
        "imageUrl": coalesce(
          image.asset->url,
          photo.asset->url
        ),
        image ${e}
      },

      partners[]{
        ...,
        "imageUrl": coalesce(
          image.asset->url,
          logo.asset->url
        ),
        image ${e}
      },

      testimonials[]->{
        _id,
        quote,
        name,
        title,
        company,
        "imageUrl": coalesce(
          image.asset->url,
          asset->url
        ),
        image ${e}
      }
    },

    "partnerGrid": {
      "eyebrow": "Our Partners",
      "heading": "Technology that powers our work",
      "description": "We work with leading commerce, marketing, ERP, customer experience, and digital platforms.",

      "partners": *[_type == "homepage"][0].partnersMarquee.partners[]{
        name,
        url,
        "imageUrl": coalesce(
          logo.asset->url,
          image.asset->url
        )
      }
    },

    vendorsSection{
      eyebrow,
      title,
      subtitle,
      items[]->{
        _id, name, category, url,
        "imageUrl": coalesce(logo.asset->url, logo.assetUrl),
        logo ${e}
      }
    },

    seo{
      title,
      description,
      metaTitle,
      metaDescription,
      "ogImage": ogImage ${e},
      noIndex
    }
  }
`},99844:(a,b,c)=>{c.d(b,{q:()=>e});var d=c(85708);let e=(0,d.createServerReference)("7f7509861306f476728bb81090cf6541f3d1e5e6e9",d.callServer,void 0,d.findSourceMapURL,"revalidateRootLayout")}};