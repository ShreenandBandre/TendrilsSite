import { defineField, defineType } from "sanity";

export default defineType({
name: "page",
title: "Standalone Page",
type: "document",
fields: [
defineField({ name: "title", type: "string", validation: (r) => r.required() }),
defineField({ name: "slug", type: "slug", options: { source: "title" }, validation: (r) => r.required() }),
defineField({ name: "body", type: "array", of: [{ type: "block" }, { type: "image" }] }),
defineField({ name: "seo", type: "seo" }),

],
});
